# coding: utf-8

from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    return 'Hello, World!'

@app.route('/blog')
def blog():
    return 'Hello, World! - blog'

@app.route('/blog/post')
def post():
    return 'Hello, World! - blog/post'
    return render_template('post.html',
                           post_content='Hello, World! (from template)')

if __name__ == '__main__':
    app.run(debug=True, port=8000)